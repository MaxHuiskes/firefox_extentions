document.addEventListener("DOMContentLoaded", async () => {
  const { allowedSites = [] } = await getTrackerStorage();
  document.getElementById("sites").value = allowedSites.join(", ");
});

document.getElementById("save").addEventListener("click", async () => {
  const rawInput = document.getElementById("sites").value;
  const allowedSites = rawInput
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

  await setTrackerStorage({ allowedSites });
  const status = document.getElementById("status");
  status.textContent = "Settings saved successfully!";
  setTimeout(() => (status.textContent = ""), 2500);
});
